#include "MyPoint.h"

void MyPoint::setPoint(int _x1, int _y1)
{
		x1 = _x1;
		y1 = _y1;
}
int MyPoint::getX1()
{
	return x1;
}
int MyPoint::getY1()
{
	return y1;
}