#pragma once

class MyPoint
{
public:
	void setPoint(int _x1, int _y1);	
	int getX1();	
	int getY1();
	
private:
	int x1;
	int y1;	
};

