

#include <iostream>
using namespace std;
#include "MyTeacher.h"

void mainxxx()
{
	MyTeacher t1;
	t1.setAge(36);
	cout<<t1.getAge()<<endl;

	cout<<"hello..."<<endl;
	system("pause");
	return ;
}