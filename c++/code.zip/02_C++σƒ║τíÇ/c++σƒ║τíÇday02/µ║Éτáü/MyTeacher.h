#pragma once  //ֻ����һ��


/*
#ifndef __MYTEACHER_H_  //ctrl +shift + u ���д
#define __MYTEACHER_H_
*/

class MyTeacher
{
private:
	int m_age;
	char m_name[32];

public:

	void setAge(int age);
	int  getAge();

};

/*
#endif
*/


