#include "MyTeacher.h"


void MyTeacher::setAge(int age)
{
	m_age = age;
}
int  MyTeacher::getAge()
{
	return m_age;
}
